#ifndef INITIALIZE_BELIEFS_H
#define INITIALIZE_BELIEFS_H

#include <vector>

std::vector< std::vector <float> > initialize_beliefs(int, int);

#endif /* INITIALIZE_BELIEFS.H */
