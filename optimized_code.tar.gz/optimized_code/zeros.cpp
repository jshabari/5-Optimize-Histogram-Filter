#include "headers/zeros.h"

using namespace std;

vector < vector <float> > zeros(int height, int width) {
	int i;
  
	// OPTIMIZATION: Reserve space in memory for vectors
	vector < vector <float> > newGrid;
    newGrid.reserve(height);
  //declaring and assigning column value to the grid
	vector <float> newRow;
    newRow.assign(width, 0);
  
  // Assigning row value to the grid
    for (i=0; i < height; i++)
    {
      newGrid.push_back(newRow);
    }
    
	return newGrid;
}